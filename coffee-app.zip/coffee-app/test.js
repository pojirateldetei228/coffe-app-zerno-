'use strict';
/* Автотест API: node test.js (использует базу в памяти, файлы не трогает) */
process.env.DB_FILE = ':memory:';
const assert = require('assert');
const { server } = require('./server.js');
let base, jar = {};
async function call(who, method, url, body) {
  const r = await fetch(base + url, { method, headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), cookie: jar[who] || '' }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.get('set-cookie'); if (sc) jar[who] = sc.split(';')[0];
  return { s: r.status, d: await r.json().catch(() => ({})) };
}
(async () => {
  await new Promise(r => server.listen(0, r)); base = 'http://127.0.0.1:' + server.address().port;
  let n = 0; const ok = (name, c) => { assert(c, name); console.log('ok  ', ++n, name); };

  ok('каталог доступен без входа', (await call('a', 'GET', '/api/products')).d.length === 13);
  ok('гость не может создать товар', (await call('a', 'POST', '/api/products', { name: 'x', cat: 'Кофе', price: 1 })).s === 401);
  ok('регистрация: короткий пароль отклонён', (await call('u', 'POST', '/api/register', { name: 'Анна', email: 'a@b.ru', password: '123' })).s === 400);
  ok('регистрация', (await call('u', 'POST', '/api/register', { name: 'Анна', email: 'a@b.ru', password: 'secret1' })).s === 200);
  ok('повторная почта отклонена', (await call('x', 'POST', '/api/register', { name: 'Б', email: 'A@b.ru', password: 'secret1' })).s === 409);
  ok('/me возвращает пользователя', (await call('u', 'GET', '/api/me')).d.user.email === 'a@b.ru');
  ok('покупатель не админ (403)', (await call('u', 'POST', '/api/products', { name: 'x', cat: 'Кофе', price: 1 })).s === 403);
  ok('статистика закрыта для покупателя', (await call('u', 'GET', '/api/stats')).s === 403);
  ok('неверный пароль', (await call('z', 'POST', '/api/login', { email: 'admin@zerno.ru', password: 'нет' })).s === 401);
  ok('вход админа', (await call('adm', 'POST', '/api/login', { email: 'admin@zerno.ru', password: 'admin123' })).s === 200);

  const p = await call('adm', 'POST', '/api/products', { name: 'Тест-латте', cat: 'Кофе', price: 250, desc: 'тест', active: true });
  ok('админ создаёт товар', p.s === 201 && p.d.price === 250);
  ok('цена валидируется', (await call('adm', 'PUT', '/api/products/' + p.d.id, { name: 'a', cat: 'Кофе', price: -5 })).s === 400);
  ok('у стандартных товаров есть картинки', (await call('u', 'GET', '/api/products')).d.every(x => x.id === p.d.id || x.img.startsWith('/img/')));
  ok('небезопасная картинка отклонена', (await call('adm', 'PUT', '/api/products/' + p.d.id, { name: 'a', cat: 'Кофе', price: 1, img: 'javascript:alert(1)' })).s === 400);
  ok('картинка по ссылке https сохраняется', (await call('adm', 'PUT', '/api/products/' + p.d.id, { name: 'Тест-латте', cat: 'Кофе', price: 250, img: 'https://example.com/a.jpg' })).d.img === 'https://example.com/a.jpg');
  ok('админ меняет товар', (await call('adm', 'PUT', '/api/products/' + p.d.id, { name: 'Тест-латте', cat: 'Кофе', price: 300, active: true })).d.price === 300);

  const o = await call('u', 'POST', '/api/orders', { name: 'Анна', phone: '+7 900 111-22-33', method: 'Самовывоз',
    items: [{ pid: p.d.id, qty: 2 }, { pid: 1, qty: 1, price: 1 }], cup: [{ sid: 'star', x: 40, y: 50 }], total: 1 });
  ok('заказ создан, сумма считается на сервере (300×2+150)', o.s === 201 && o.d.total === 750 && o.d.cup.length === 1);
  ok('несуществующий стикер отклонён', (await call('u', 'POST', '/api/orders', { name: 'А', phone: '+79001112233', items: [{ pid: 1, qty: 1 }], cup: [{ sid: 'hack', x: 1, y: 1 }] })).s === 400);
  ok('пустая корзина отклонена', (await call('u', 'POST', '/api/orders', { name: 'А', phone: '+79001112233', items: [] })).s === 400);
  ok('покупатель видит только свои заказы', (await call('u', 'GET', '/api/orders')).d.length === 1);
  ok('админ видит все заказы', (await call('adm', 'GET', '/api/orders')).d.length > 100);
  ok('чужой заказ недоступен', (await call('z', 'GET', '/api/orders/' + o.d.id)).s === 401);
  ok('смена статуса', (await call('adm', 'PUT', `/api/orders/${o.d.id}/status`, { status: 'Готовится' })).s === 200);
  ok('скрытый товар не продаётся', (await call('adm', 'PUT', '/api/products/' + p.d.id, { name: 'Тест-латте', cat: 'Кофе', price: 300, active: false })).d.active === false
    && (await call('u', 'POST', '/api/orders', { name: 'А', phone: '+79001112233', items: [{ pid: p.d.id, qty: 1 }] })).s === 409);

  const st = (await call('adm', 'GET', '/api/stats?days=7&tz=0')).d;
  ok('статистика: 7 дней и сходимость сумм', st.byDay.length === 7 && st.byDay.reduce((a, d) => a + d.v, 0) === st.rev && st.top.reduce((a, t) => a + t.s, 0) === st.rev);
  ok('удаление демо-заказов', (await call('adm', 'DELETE', '/api/orders-demo')).d.removed > 100);
  ok('удаление товара', (await call('adm', 'DELETE', '/api/products/' + p.d.id)).s === 200);
  ok('выход', (await call('u', 'POST', '/api/logout', {})).s === 200 && (await call('u', 'GET', '/api/me')).d.user === null);
  const bad = await fetch(base + '/..%2f..%2fetc/passwd'); ok('защита от выхода из public/', bad.status === 404);
  console.log('\nВсе проверки пройдены:', n); server.close(); process.exit(0);
})().catch(e => { console.error('ПРОВАЛ:', e.message); process.exit(1); });
