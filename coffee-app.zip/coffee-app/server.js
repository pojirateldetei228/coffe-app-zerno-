'use strict';
/* Бэкенд кофейни «Зерно». Без внешних зависимостей: Node.js >= 22.5 (встроенный node:sqlite). */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT) || 3000;
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data', 'coffee.db');
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'admin@zerno.ru').toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const PUBLIC = path.join(__dirname, 'public');
const CATS = ['Кофе', 'Чай', 'Десерты', 'Зерно'];
const STICKER_IDS = ['star', 'heart', 'bolt', 'sun', 'bean', 'leaf'];
const STATUSES = ['Новый', 'Готовится', 'Выдан'];

/* ---------- База данных ---------- */
if (DB_FILE !== ':memory:') fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
const db = new DatabaseSync(DB_FILE);
db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  pass_hash TEXT NOT NULL, salt TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS products(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, cat TEXT NOT NULL, price INTEGER NOT NULL CHECK(price>=0),
  descr TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS posts(
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, tag TEXT NOT NULL, body TEXT NOT NULL, ts INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS stickers(id TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', method TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Новый', total INTEGER NOT NULL, cup TEXT NOT NULL DEFAULT '[]', demo INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS order_items(
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER, name TEXT NOT NULL, cat TEXT NOT NULL, price INTEGER NOT NULL, qty INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_orders_ts ON orders(ts);
CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id);
`);
const q = {
  get: (sql, ...a) => db.prepare(sql).get(...a),
  all: (sql, ...a) => db.prepare(sql).all(...a),
  run: (sql, ...a) => db.prepare(sql).run(...a),
};
function tx(fn) {
  db.exec('BEGIN');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}

/* ---------- Пароли и сессии ---------- */
function hashPass(pass, salt = crypto.randomBytes(16).toString('hex')) {
  return { salt, hash: crypto.scryptSync(pass, salt, 64).toString('hex') };
}
function checkPass(pass, salt, hash) {
  const a = Buffer.from(crypto.scryptSync(pass, salt, 64).toString('hex'));
  const b = Buffer.from(hash);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function createUser(name, email, pass, role = 'user') {
  const { salt, hash } = hashPass(pass);
  return Number(q.run('INSERT INTO users(name,email,pass_hash,salt,role,created_at) VALUES(?,?,?,?,?,?)', name, email, hash, salt, role, Date.now()).lastInsertRowid);
}
const SESSION_TTL = 30 * 864e5;
function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}
function userFromReq(req) {
  const t = parseCookies(req).sid;
  if (!t) return null;
  const s = q.get('SELECT u.id,u.name,u.email,u.role,s.created_at sc FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?', t);
  if (!s) return null;
  if (Date.now() - s.sc > SESSION_TTL) { q.run('DELETE FROM sessions WHERE token=?', t); return null; }
  return { id: s.id, name: s.name, email: s.email, role: s.role };
}
const cookie = (v, age) => `sid=${v}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${age}`;

/* ---------- Данные по умолчанию ---------- */
function seedIfEmpty() {
  if (!q.get('SELECT COUNT(*) c FROM users').c) createUser('Администратор', ADMIN_EMAIL, ADMIN_PASSWORD, 'admin');
  if (!q.get('SELECT COUNT(*) c FROM stickers').c) STICKER_IDS.forEach(id => q.run('INSERT INTO stickers(id,enabled) VALUES(?,1)', id));
  if (q.get('SELECT COUNT(*) c FROM products').c) return;
  const products = [
    ['Эспрессо', 'Кофе', 150, 'Двойной, плотный, с карамельной сладостью.'],
    ['Американо', 'Кофе', 180, 'Эспрессо и горячая вода, чистый вкус.'],
    ['Капучино', 'Кофе', 230, 'Эспрессо, молоко, плотная пенка.'],
    ['Флэт уайт', 'Кофе', 260, 'Двойной ристретто с бархатным молоком.'],
    ['Раф ванильный', 'Кофе', 290, 'Сливки, ванильный сахар, эспрессо.'],
    ['Колд брю', 'Кофе', 270, 'Настаивается 16 часов, подаётся со льдом.'],
    ['Улун молочный', 'Чай', 220, 'Мягкий сливочный аромат, 400 мл.'],
    ['Матча-латте', 'Чай', 310, 'Японская матча и овсяное молоко.'],
    ['Круассан миндальный', 'Десерты', 210, 'Слоёный, с франжипаном, выпекаем утром.'],
    ['Баскский чизкейк', 'Десерты', 340, 'Карамелизированная корочка, нежный центр.'],
    ['Брауни', 'Десерты', 200, 'Тёмный шоколад и грецкий орех.'],
    ['Эфиопия Иргачефф, 250 г', 'Зерно', 890, 'Жасмин, бергамот, персик. Светлая обжарка.'],
    ['Бразилия Сантос, 250 г', 'Зерно', 690, 'Орех, какао, мягкая кислотность.'],
  ];
  tx(() => {
    products.forEach(p => q.run('INSERT INTO products(name,cat,price,descr) VALUES(?,?,?,?)', ...p));
    const day = 864e5, now = Date.now();
    [['Обжарка', 'Как мы обжариваем зерно', 9, 'Обжариваем небольшими партиями по 12 кг, чтобы следить за каждой секундой первого и второго треска.\nДля фильтра берём светлую обжарку и останавливаем её раньше, для эспрессо даём зерну ещё 40 секунд.\nКаждую партию дегустируем на следующий день, когда зерно отдало лишний газ.'],
     ['Дома', 'Эспрессо дома: пять правил', 4, '1. Взвешивайте дозу, а не считайте ложки.\n2. Мелите перед каждой чашкой.\n3. Следите за временем: 25–30 секунд на 36 г напитка.\n4. Прогревайте чашку.\n5. Меняйте помол, а не рецепт, если вкус кислый или горький.'],
     ['Меню', 'Флэт уайт и капучино: в чём разница', 1, 'Капучино — это треть эспрессо, треть молока и треть пены. Во флэт уайт пены почти нет, зато больше кофе: два ристретто и 130 мл микропены.\nВкус у флэт уайт плотнее, у капучино мягче и воздушнее.']]
      .forEach(([tag, title, ago, body]) => q.run('INSERT INTO posts(title,tag,body,ts) VALUES(?,?,?,?)', title, tag, body, now - ago * day));
    seedDemoOrders();
  });
}
/* демо-заказы за 30 дней, чтобы страница статистики сразу была заполнена; помечены demo=1 */
function seedDemoOrders() {
  let s = 7; const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const prods = q.all('SELECT * FROM products ORDER BY id');
  const w = [5, 6, 9, 5, 3, 4, 3, 3, 4, 3, 3, 1, 1];
  const pick = () => { let r = rnd() * w.reduce((a, b) => a + b, 0), i = 0; while (r > w[i]) { r -= w[i]; i++; } return prods[i]; };
  const today = new Date(); today.setHours(0, 0, 0, 0);
  let num = 1000;
  for (let d = 29; d >= 0; d--) {
    const day = new Date(today); day.setDate(day.getDate() - d);
    const n = Math.round(6 + rnd() * 6 + ([0, 6].includes(day.getDay()) ? 4 : 0) + (29 - d) * 0.1);
    for (let k = 0; k < n; k++) {
      const items = [];
      for (let j = 1 + Math.floor(rnd() * 3); j > 0; j--) {
        const p = pick(), ex = items.find(x => x.p.id === p.id);
        if (ex) ex.qty++; else items.push({ p, qty: 1 + (rnd() > 0.8 ? 1 : 0) });
      }
      const hr = Math.min(20, Math.max(8, Math.round(8 + Math.abs(rnd() + rnd() + rnd() - 1.5) * 8)));
      const ts = day.getTime() + hr * 3600000 + Math.floor(rnd() * 3600000);
      const total = items.reduce((a, i) => a + i.p.price * i.qty, 0);
      const id = q.run('INSERT INTO orders(id,ts,name,method,status,total,demo) VALUES(?,?,?,?,?,?,1)', ++num, ts, 'Гость', 'Самовывоз', 'Выдан', total).lastInsertRowid;
      items.forEach(i => q.run('INSERT INTO order_items(order_id,product_id,name,cat,price,qty) VALUES(?,?,?,?,?,?)', id, i.p.id, i.p.name, i.p.cat, i.p.price, i.qty));
    }
  }
}
seedIfEmpty();

/* ---------- Картинки товаров ---------- */
if (!q.all('PRAGMA table_info(products)').some(c => c.name === 'img')) db.exec("ALTER TABLE products ADD COLUMN img TEXT NOT NULL DEFAULT ''");
const DEFAULT_IMG = {
  'Эспрессо': 'espresso', 'Американо': 'americano', 'Капучино': 'cappuccino', 'Флэт уайт': 'flat-white',
  'Раф ванильный': 'raf', 'Колд брю': 'cold-brew', 'Улун молочный': 'oolong', 'Матча-латте': 'matcha',
  'Круассан миндальный': 'croissant', 'Баскский чизкейк': 'cheesecake', 'Брауни': 'brownie',
  'Эфиопия Иргачефф, 250 г': 'ethiopia', 'Бразилия Сантос, 250 г': 'brazil',
};
// Только для товаров без картинки: свои картинки администратора не затираются.
for (const [name, file] of Object.entries(DEFAULT_IMG)) q.run("UPDATE products SET img=? WHERE name=? AND img=''", `/img/${file}.svg`, name);

/* ---------- Представления (строка БД -> JSON для клиента; id всегда строка) ---------- */
const vProduct = r => ({ id: String(r.id), name: r.name, cat: r.cat, price: r.price, desc: r.descr, img: r.img || '', active: !!r.active });
const vPost = r => ({ id: String(r.id), title: r.title, tag: r.tag, body: r.body, ts: r.ts });
function vOrders(rows) {
  if (!rows.length) return [];
  const ids = rows.map(r => r.id);
  const items = q.all(`SELECT * FROM order_items WHERE order_id IN (${ids.map(() => '?').join(',')}) ORDER BY id`, ...ids);
  return rows.map(r => ({
    id: String(r.id), num: r.id, ts: r.ts, userId: r.user_id, name: r.name, phone: r.phone, method: r.method, note: r.note,
    status: r.status, total: r.total, demo: !!r.demo, cup: JSON.parse(r.cup),
    items: items.filter(i => i.order_id === r.id).map(i => ({ pid: String(i.product_id), name: i.name, cat: i.cat, price: i.price, qty: i.qty })),
  }));
}

/* ---------- Утилиты HTTP ---------- */
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const bad = (msg, code = 400) => { throw new HttpError(code, msg); };
function send(res, code, obj, headers = {}) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    if (['GET', 'HEAD'].includes(req.method)) return resolve({});
    if (!(req.headers['content-type'] || '').includes('application/json')) return req.method === 'DELETE' ? resolve({}) : reject(new HttpError(415, 'Нужен Content-Type: application/json'));
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > 100000) { reject(new HttpError(413, 'Слишком большой запрос')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {}); } catch { reject(new HttpError(400, 'Некорректный JSON')); } });
    req.on('error', reject);
  });
}
const str = (v, name, min = 1, max = 500) => {
  if (typeof v !== 'string') bad(`Поле «${name}» обязательно`);
  const t = v.trim();
  if (t.length < min || t.length > max) bad(`Поле «${name}»: от ${min} до ${max} символов`);
  return t;
};
const needUser = c => c.user || bad('Нужно войти', 401);
const needAdmin = c => { needUser(c); if (c.user.role !== 'admin') bad('Недостаточно прав', 403); };
const idParam = s => { const n = Number(s); if (!Number.isInteger(n) || n < 1) bad('Некорректный id'); return n; };

const attempts = new Map(); // простая защита от перебора пароля
function throttle(ip) {
  const now = Date.now(), a = (attempts.get(ip) || []).filter(t => now - t < 60000);
  if (a.length >= 10) bad('Слишком много попыток. Подождите минуту.', 429);
  a.push(now); attempts.set(ip, a);
}

/* ---------- Маршруты API ---------- */
const routes = [];
const route = (m, p, h) => routes.push([m, new RegExp('^' + p.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), h]);

route('GET', '/api/me', c => ({ user: c.user }));

route('POST', '/api/register', c => {
  throttle(c.ip);
  const name = str(c.body.name, 'Имя', 1, 60), email = str(c.body.email, 'Почта', 3, 120).toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) bad('Проверьте адрес почты');
  const pass = typeof c.body.password === 'string' ? c.body.password : '';
  if (pass.length < 6 || pass.length > 100) bad('Пароль должен быть не короче 6 символов');
  if (q.get('SELECT 1 x FROM users WHERE email=?', email)) bad('Эта почта уже зарегистрирована. Войдите.', 409);
  const id = createUser(name, email, pass);
  return startSession(c, id);
});
route('POST', '/api/login', c => {
  throttle(c.ip);
  const email = str(c.body.email, 'Почта', 3, 120).toLowerCase(), pass = typeof c.body.password === 'string' ? c.body.password : '';
  const u = q.get('SELECT * FROM users WHERE email=?', email);
  if (!u || !checkPass(pass, u.salt, u.pass_hash)) bad('Неверная почта или пароль', 401);
  return startSession(c, u.id);
});
function startSession(c, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  q.run('INSERT INTO sessions(token,user_id,created_at) VALUES(?,?,?)', token, userId, Date.now());
  const u = q.get('SELECT id,name,email,role FROM users WHERE id=?', userId);
  c.headers['Set-Cookie'] = cookie(token, SESSION_TTL / 1000);
  return { user: u };
}
route('POST', '/api/logout', c => {
  const t = parseCookies(c.req).sid;
  if (t) q.run('DELETE FROM sessions WHERE token=?', t);
  c.headers['Set-Cookie'] = cookie('', 0);
  return { ok: true };
});

/* товары */
route('GET', '/api/products', c => {
  const all = c.user?.role === 'admin' && c.query.get('all') === '1';
  return q.all(`SELECT * FROM products ${all ? '' : 'WHERE active=1'} ORDER BY id`).map(vProduct);
});
function productInput(b) {
  const cat = str(b.cat, 'Категория');
  if (!CATS.includes(cat)) bad('Неизвестная категория');
  const price = Number(b.price);
  if (!Number.isInteger(price) || price < 0 || price > 1000000) bad('Цена: целое число от 0');
  let img = null; // null = не менять (для PUT) / пусто (для POST)
  if (b.img !== undefined) {
    img = typeof b.img === 'string' ? b.img.trim() : '';
    if (img && !(img.length <= 300 && /^(\/img\/[\w.-]+|https:\/\/[^\s"'<>]+)$/.test(img))) bad('Картинка: путь вида /img/файл.jpg или ссылка https://');
  }
  return { name: str(b.name, 'Название', 1, 120), cat, price, descr: typeof b.desc === 'string' ? b.desc.trim().slice(0, 500) : '', img, active: b.active === false ? 0 : 1 };
}
route('POST', '/api/products', c => {
  needAdmin(c); const p = productInput(c.body);
  const id = q.run('INSERT INTO products(name,cat,price,descr,img,active) VALUES(?,?,?,?,?,?)', p.name, p.cat, p.price, p.descr, p.img ?? '', p.active).lastInsertRowid;
  c.status = 201; return vProduct(q.get('SELECT * FROM products WHERE id=?', id));
});
route('PUT', '/api/products/:id', c => {
  needAdmin(c); const id = idParam(c.params.id), p = productInput(c.body);
  if (!q.run('UPDATE products SET name=?,cat=?,price=?,descr=?,img=COALESCE(?,img),active=? WHERE id=?', p.name, p.cat, p.price, p.descr, p.img, p.active, id).changes) bad('Товар не найден', 404);
  return vProduct(q.get('SELECT * FROM products WHERE id=?', id));
});
route('DELETE', '/api/products/:id', c => {
  needAdmin(c);
  if (!q.run('DELETE FROM products WHERE id=?', idParam(c.params.id)).changes) bad('Товар не найден', 404);
  return { ok: true };
});

/* блог */
route('GET', '/api/posts', () => q.all('SELECT * FROM posts ORDER BY ts DESC').map(vPost));
function postInput(b) { return { title: str(b.title, 'Заголовок', 1, 150), tag: typeof b.tag === 'string' && b.tag.trim() ? b.tag.trim().slice(0, 40) : 'Новости', body: str(b.body, 'Текст', 1, 10000) }; }
route('POST', '/api/posts', c => {
  needAdmin(c); const p = postInput(c.body);
  const id = q.run('INSERT INTO posts(title,tag,body,ts) VALUES(?,?,?,?)', p.title, p.tag, p.body, Date.now()).lastInsertRowid;
  c.status = 201; return vPost(q.get('SELECT * FROM posts WHERE id=?', id));
});
route('PUT', '/api/posts/:id', c => {
  needAdmin(c); const id = idParam(c.params.id), p = postInput(c.body);
  if (!q.run('UPDATE posts SET title=?,tag=?,body=? WHERE id=?', p.title, p.tag, p.body, id).changes) bad('Запись не найдена', 404);
  return vPost(q.get('SELECT * FROM posts WHERE id=?', id));
});
route('DELETE', '/api/posts/:id', c => {
  needAdmin(c);
  if (!q.run('DELETE FROM posts WHERE id=?', idParam(c.params.id)).changes) bad('Запись не найдена', 404);
  return { ok: true };
});

/* стикеры */
route('GET', '/api/stickers', () => q.all('SELECT id,enabled FROM stickers ORDER BY rowid').map(s => ({ id: s.id, on: !!s.enabled })));
route('PUT', '/api/stickers/:id', c => {
  needAdmin(c);
  if (typeof c.body.on !== 'boolean') bad('Поле «on» должно быть true или false');
  if (!q.run('UPDATE stickers SET enabled=? WHERE id=?', c.body.on ? 1 : 0, c.params.id).changes) bad('Стикер не найден', 404);
  return { id: c.params.id, on: c.body.on };
});

/* заказы: цены считает сервер, клиенту не доверяем */
route('POST', '/api/orders', c => {
  needUser(c); const b = c.body;
  const name = str(b.name, 'Имя', 1, 60), phone = str(b.phone, 'Телефон', 7, 30);
  if (!/^[+\d][\d\s()-]{6,}$/.test(phone)) bad('Телефон: например, +7 900 000-00-00');
  const method = b.method === 'Доставка' ? 'Доставка' : 'Самовывоз';
  const note = typeof b.note === 'string' ? b.note.trim().slice(0, 300) : '';
  if (!Array.isArray(b.items) || !b.items.length || b.items.length > 50) bad('Корзина пуста');
  const enabled = new Set(q.all('SELECT id FROM stickers WHERE enabled=1').map(s => s.id));
  const cup = (Array.isArray(b.cup) ? b.cup : []).slice(0, 20).map(s => {
    if (!s || !enabled.has(s.sid) || !(s.x >= 0 && s.x <= 100) || !(s.y >= 0 && s.y <= 100)) bad('Некорректный стикер');
    return { sid: s.sid, x: Math.round(s.x * 10) / 10, y: Math.round(s.y * 10) / 10 };
  });
  return tx(() => {
    const lines = new Map();
    for (const it of b.items) {
      const pid = Number(it?.pid), qty = Number(it?.qty);
      if (!Number.isInteger(pid) || !Number.isInteger(qty) || qty < 1 || qty > 50) bad('Некорректная позиция в заказе');
      const p = q.get('SELECT * FROM products WHERE id=? AND active=1', pid);
      if (!p) bad('Один из товаров недоступен. Обновите корзину.', 409);
      const cur = lines.get(pid); lines.set(pid, { p, qty: (cur?.qty || 0) + qty });
    }
    const total = [...lines.values()].reduce((a, l) => a + l.p.price * l.qty, 0);
    const id = q.run('INSERT INTO orders(ts,user_id,name,phone,method,note,status,total,cup) VALUES(?,?,?,?,?,?,?,?,?)',
      Date.now(), c.user.id, name, phone, method, note, 'Новый', total, JSON.stringify(cup)).lastInsertRowid;
    lines.forEach(l => q.run('INSERT INTO order_items(order_id,product_id,name,cat,price,qty) VALUES(?,?,?,?,?,?)', id, l.p.id, l.p.name, l.p.cat, l.p.price, l.qty));
    c.status = 201;
    return vOrders(q.all('SELECT * FROM orders WHERE id=?', id))[0];
  });
});
route('GET', '/api/orders', c => {
  needUser(c);
  const rows = c.user.role === 'admin'
    ? q.all('SELECT * FROM orders ORDER BY ts DESC LIMIT 200')
    : q.all('SELECT * FROM orders WHERE user_id=? ORDER BY ts DESC LIMIT 200', c.user.id);
  return vOrders(rows);
});
route('GET', '/api/orders/:id', c => {
  needUser(c);
  const r = q.get('SELECT * FROM orders WHERE id=?', idParam(c.params.id));
  if (!r || (r.user_id !== c.user.id && c.user.role !== 'admin')) bad('Заказ не найден', 404);
  return vOrders([r])[0];
});
route('PUT', '/api/orders/:id/status', c => {
  needAdmin(c);
  if (!STATUSES.includes(c.body.status)) bad('Неизвестный статус');
  if (!q.run('UPDATE orders SET status=? WHERE id=?', c.body.status, idParam(c.params.id)).changes) bad('Заказ не найден', 404);
  return { ok: true };
});
route('DELETE', '/api/orders-demo', c => { needAdmin(c); return { removed: Number(q.run('DELETE FROM orders WHERE demo=1').changes) }; });

/* статистика: агрегаты считаются на сервере */
route('GET', '/api/stats', c => {
  needAdmin(c);
  const days = Math.min(90, Math.max(1, parseInt(c.query.get('days')) || 14));
  const off = (parseInt(c.query.get('tz')) || 0) * 60000; // getTimezoneOffset() клиента, мин
  const DAY = 864e5;
  const startLocal = Math.floor((Date.now() - off) / DAY) * DAY - (days - 1) * DAY;
  const orders = vOrders(q.all('SELECT * FROM orders WHERE ts>=?', startLocal + off));
  const dayRows = Array.from({ length: days }, (_, i) => {
    const d = new Date(startLocal + i * DAY);
    return { l: String(d.getUTCDate()).padStart(2, '0') + '.' + String(d.getUTCMonth() + 1).padStart(2, '0'), v: 0, c: 0 };
  });
  const hours = Array.from({ length: 13 }, (_, i) => ({ l: String(i + 8), v: 0 }));
  const prod = {}, cats = {};
  let rev = 0;
  for (const o of orders) {
    rev += o.total;
    const di = Math.floor((o.ts - off - startLocal) / DAY);
    if (dayRows[di]) { dayRows[di].v += o.total; dayRows[di].c++; }
    const h = new Date(o.ts - off).getUTCHours();
    if (h >= 8 && h <= 20) hours[h - 8].v++;
    for (const i of o.items) {
      const r = prod[i.name] || (prod[i.name] = { name: i.name, cat: i.cat, q: 0, s: 0 });
      r.q += i.qty; r.s += i.qty * i.price; cats[i.cat] = (cats[i.cat] || 0) + i.qty * i.price;
    }
  }
  return { days, rev, cnt: orders.length, avg: orders.length ? rev / orders.length : 0, byDay: dayRows, hours, cats,
    top: Object.values(prod).sort((a, b) => b.s - a.s) };
});

/* ---------- Сервер ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon' };
function serveStatic(req, res) {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Не найдено'); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(file).pipe(res);
}
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  try {
    const url = new URL(req.url, 'http://x');
    if (!url.pathname.startsWith('/api/')) return serveStatic(req, res);
    for (const [m, re, h] of routes) {
      const mt = m === req.method && re.exec(url.pathname);
      if (!mt) continue;
      const c = { req, res, params: mt.groups || {}, query: url.searchParams, user: userFromReq(req), body: await readBody(req), headers: {}, status: 200, ip: req.socket.remoteAddress };
      const out = h(c);
      return send(res, c.status, out, c.headers);
    }
    send(res, 404, { error: 'Маршрут не найден' });
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.code, { error: e.message });
    console.error(e); send(res, 500, { error: 'Внутренняя ошибка сервера' });
  }
});
if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`Кофейня «Зерно»: http://localhost:${PORT}`);
    if (ADMIN_PASSWORD === 'admin123') console.log('Внимание: используется пароль администратора по умолчанию. Задайте ADMIN_PASSWORD при первом запуске.');
  });
}
module.exports = { server, db };
